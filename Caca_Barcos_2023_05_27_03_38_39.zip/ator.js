//códigos ator

function mostraAtor(){
  image(imagemAviao, mouseX, height - 80, 70, 70);
}



